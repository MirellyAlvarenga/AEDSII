public interface IBuscador<T> extends IMedicao {
    
	public T buscar (T dado);
}  