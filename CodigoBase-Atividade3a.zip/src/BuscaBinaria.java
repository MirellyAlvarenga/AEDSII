import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Comparator;

public class BuscaBinaria<T> implements IBuscador<T> {

	@Override
	public long getComparacoes() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getTempo() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public T buscar(T dado) {
		// TODO Auto-generated method stub
		return null;
	}
}
